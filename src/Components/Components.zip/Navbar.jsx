import React, { useState, useRef } from "react";
import { Link } from "react-scroll";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faBookOpen, faBars, faTimes, faChevronDown } from "@fortawesome/free-solid-svg-icons";

const Navbar = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const dropdownTimeout = useRef(null);

  const toggleMenu = () => setMenuOpen(!menuOpen);

  // Open dropdown immediately
  const handleMouseEnter = () => {
    if (dropdownTimeout.current) clearTimeout(dropdownTimeout.current); // Cancel closing
    setDropdownOpen(true);
  };

  // Delay dropdown close by 300ms when mouse leaves
  const handleMouseLeave = () => {
    dropdownTimeout.current = setTimeout(() => setDropdownOpen(false), 300);
  };

  return (
    <nav className="bg-black bg-opacity-90 py-4 px-6 flex justify-between items-center fixed w-full top-0 z-50">
      {/* Logo (Click to Navigate Home) */}
      <div className="flex items-center space-x-2 cursor-pointer">
        <Link to="home" smooth={true} duration={800} offset={-80} className="flex items-center space-x-2">
          <FontAwesomeIcon icon={faBookOpen} className="text-green-500 text-3xl" />
          <h1 className="text-xl font-bold text-white">EDUCATION</h1>
        </Link>
      </div>

      {/* Desktop Menu */}
      <ul className="hidden md:flex space-x-6 items-center">
        {["home", "about", "courses", "contact"].map((item) => (
          <li key={item}>
            <Link to={item} smooth={true} duration={800} offset={-80} className="text-white cursor-pointer hover:text-green-400">
              {item.charAt(0).toUpperCase() + item.slice(1)}
            </Link>
          </li>
        ))}

        {/* Dropdown Menu with Delay */}
        <li className="relative" onMouseEnter={handleMouseEnter} onMouseLeave={handleMouseLeave}>
          <button className="text-white flex items-center space-x-1 hover:text-green-400">
            <span>More</span>
            <FontAwesomeIcon icon={faChevronDown} />
          </button>

          {dropdownOpen && (
            <ul 
              className="absolute right-0 mt-2 w-48 bg-gray-900 text-white rounded-md shadow-lg border border-gray-700"
              onMouseEnter={handleMouseEnter} 
              onMouseLeave={handleMouseLeave} 
            >
              {["features", "teachers", "programs", "testimonials", "blog", "newsletter"].map((item) => (
                <Link 
                  key={item} 
                  to={item} 
                  smooth={true} 
                  duration={800} 
                  offset={-80} 
                  className="block w-full p-3 text-center hover:bg-green-500 cursor-pointer transition" 
                  onClick={() => setDropdownOpen(false)}
                >
                  {item.charAt(0).toUpperCase() + item.slice(1)}
                </Link>
              ))}
            </ul>
          )}
        </li>
      </ul>

{/* Mobile Menu Button */}
<button className="md:hidden text-white text-2xl focus:outline-none" onClick={toggleMenu}>
  <FontAwesomeIcon icon={menuOpen ? faTimes : faBars} />
</button>

      {/* Mobile Menu */}
      {menuOpen && (
        <div className="fixed top-0 left-0 w-full h-screen bg-black bg-opacity-60 backdrop-blur-md flex flex-col items-center justify-center space-y-8 transition-opacity duration-300">
          
          {/* Close Button */}
          <button className="absolute top-5 right-6 text-3xl text-white hover:text-red-400 transition" onClick={toggleMenu}>
            <FontAwesomeIcon icon={faTimes} />
          </button>

          {/* Navigation Links */}
          {["home", "about", "courses", "contact"].map((item) => (
            <Link 
              key={item} 
              to={item} 
              smooth={true} 
              duration={800} 
              offset={-80} 
              className="text-white text-2xl text-center w-full h-10 rounded-lg hover:bg-green-500 hover:bg-opacity-30 transition-all duration-300 cursor-pointer"
              onClick={() => setMenuOpen(false)}
            >
              {item.charAt(0).toUpperCase() + item.slice(1)}
            </Link>
          ))}

          {/* Mobile Dropdown */}
          <button 
            className="text-white text-2xl font-semibold flex items-center space-x-2 hover:text-green-400 transition-all duration-300" 
            onClick={() => setDropdownOpen(!dropdownOpen)}
          >
            <span>More</span> 
            <FontAwesomeIcon icon={faChevronDown} className={`transform transition-all ${dropdownOpen ? "rotate-180" : ""}`} />
          </button>

          {/* Dropdown Menu */}
          {dropdownOpen && (
            <div className="bg-gray-900 bg-opacity-80 backdrop-blur-md text-white rounded-xl shadow-lg border border-gray-700 px-8 py-6 flex flex-col items-center space-y-4 transition-all duration-300">
              {["features", "teachers", "programs", "testimonials", "blog", "newsletter"].map((item) => (
                <Link 
                  key={item} 
                  to={item} 
                  smooth={true} 
                  duration={800} 
                  offset={-80} 
                  className="block text-xl py-1 px-3 rounded-lg hover:bg-green-500 hover:bg-opacity-30 transition-all duration-300 cursor-pointer"
                  onClick={() => { setDropdownOpen(false); setMenuOpen(false); }}
                >
                  {item.charAt(0).toUpperCase() + item.slice(1)}
                </Link>
              ))}
            </div>
          )}
        </div>
      )}
    </nav>
  );
};

export default Navbar;
